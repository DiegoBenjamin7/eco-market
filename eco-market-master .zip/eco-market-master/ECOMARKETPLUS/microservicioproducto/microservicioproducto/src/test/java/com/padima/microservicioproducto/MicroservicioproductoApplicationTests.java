package com.padima.microservicioproducto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioproductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
