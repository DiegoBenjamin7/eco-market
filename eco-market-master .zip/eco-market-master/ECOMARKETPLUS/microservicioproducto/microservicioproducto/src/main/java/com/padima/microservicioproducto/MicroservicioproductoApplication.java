package com.padima.microservicioproducto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioproductoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioproductoApplication.class, args);
	}

}
