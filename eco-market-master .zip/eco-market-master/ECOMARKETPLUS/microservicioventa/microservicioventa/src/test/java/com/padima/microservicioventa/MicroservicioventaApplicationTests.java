package com.padima.microservicioventa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioventaApplicationTests {

	@Test
	void contextLoads() {
	}

}
