package com.padima.microservicioventa.testVentaService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.padima.microservicioventa.repository.ventaRepository;
import com.padima.microservicioventa.service.ventaService;
import com.padima.microservicioventa.model.venta;

@ExtendWith(MockitoExtension.class)
public class TestVentaService {

    @Mock
    private ventaRepository ventaRepository;

    @InjectMocks
    private ventaService ventaService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testBuscarTodaVenta() {
        List<venta> listaVenta = new ArrayList<>();

        venta v1 = new venta();
        v1.setIdventa(1L);
        v1.setTotalventa("50000");
        v1.setRutusuario("12345678-9");
        v1.setFechaventa(LocalDate.now());

        listaVenta.add(v1);

        when(ventaRepository.findAll()).thenReturn(listaVenta);
        List<venta> resultado = ventaService.BuscarTodaVenta();
        assertEquals(1, resultado.size());
        verify(ventaRepository, times(1)).findAll();
    }

    @Test
    public void testBuscarUnaVenta() {
        venta v1 = new venta();
        v1.setIdventa(1L);
        v1.setTotalventa("75000");
        v1.setRutusuario("18765432-1");
        v1.setFechaventa(LocalDate.now().minusDays(1));

        when(ventaRepository.findById(1L)).thenReturn(Optional.of(v1));
        venta ventaBuscada = ventaService.BuscarUnaVenta(1L);
        assertEquals(1L, ventaBuscada.getIdventa());
        verify(ventaRepository, times(1)).findById(1L);
    }

    @Test
    public void testGuardarVenta() {
        venta v1 = new venta();
        v1.setIdventa(1L);
        v1.setTotalventa("120000");
        v1.setRutusuario("11222333-4");
        v1.setFechaventa(LocalDate.now());

        when(ventaRepository.save(v1)).thenReturn(v1);
        venta ventaGuardada = ventaService.GuardarVenta(v1);
        assertEquals(1L, ventaGuardada.getIdventa());
        verify(ventaRepository, times(1)).save(v1);
    }

    @Test
    public void testEliminarVenta() {
        Long idVenta = 1L;
        doNothing().when(ventaRepository).deleteById(idVenta);

        ventaService.EliminarVenta(idVenta);
        verify(ventaRepository, times(1)).deleteById(idVenta);
    }
}
