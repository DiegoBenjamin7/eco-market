package com.padima.microservicioventa.assembler;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.padima.microservicioventa.controller.ventaController;
import com.padima.microservicioventa.model.venta;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class VentaModelAssembler implements RepresentationModelAssembler<venta, EntityModel<venta>> {

    @Override
    public EntityModel<venta> toModel(venta venta) {
        return EntityModel.of(
            venta,
            // Enlaces para operaciones básicas CRUD
            linkTo(methodOn(ventaController.class).BuscarVenta(venta.getIdventa())).withRel("consultar"),
            linkTo(methodOn(ventaController.class).ListarVentas()).withRel("listar"),
            linkTo(methodOn(ventaController.class).GuardarVenta(venta)).withRel("registrar"),
            linkTo(methodOn(ventaController.class).ActualizarVenta(venta.getIdventa(), venta)).withRel("actualizar"),
            linkTo(methodOn(ventaController.class).EliminarVenta(venta.getIdventa())).withRel("eliminar"),
            
            
            linkTo(methodOn(ventaController.class).DatosVentaUsuario(venta.getIdventa())).withRel("datos-usuario")
        );
    }
}
