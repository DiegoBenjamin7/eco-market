package com.padima.microservicioventa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.padima.microservicioventa.model.venta;

public interface ventaRepository extends JpaRepository<venta,Long>{

}
