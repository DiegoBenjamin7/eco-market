package com.padima.microservicioventa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.padima.microservicioventa.DTO.UsuarioDTO;
import com.padima.microservicioventa.DTO.ventaUsuarioDTO;
import com.padima.microservicioventa.model.venta;
import com.padima.microservicioventa.service.ventaService;
import org.springframework.web.bind.annotation.PutMapping;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/ventas")
@Tag(name = "Ventas", description = "API para la gestión de ventas")
public class ventaController {

    @Autowired
    private ventaService ventaservice;

    @GetMapping
    @Operation(summary = "Listar todas las ventas")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Ventas listadas correctamente"),
        @ApiResponse(responseCode = "404", description = "No se encuentran datos"),
        @ApiResponse(responseCode = "500", description = "Error al obtener ventas")
    })
    public ResponseEntity<?> ListarVentas() {
        List<venta> ventas = ventaservice.BuscarTodaVenta();
        if (ventas.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no se encuentran datos");
        } else {
            return ResponseEntity.ok(ventas);
        }
    }

    @GetMapping("/{idventa}")
    @Operation(summary = "Buscar una venta por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Venta encontrada"),
        @ApiResponse(responseCode = "404", description = "Venta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al buscar venta")
    })
    public ResponseEntity<?> BuscarVenta(@PathVariable Long idventa) {
        try {
            venta ventabuscada = ventaservice.BuscarUnaVenta(idventa);
            return ResponseEntity.ok(ventabuscada);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no se encuentran ventas");
        }
    }

    @GetMapping("/VentaUsuario/{idventa}")
    @Operation(summary = "Obtener datos de la venta junto al usuario")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Datos de venta y usuario obtenidos"),
        @ApiResponse(responseCode = "404", description = "Venta o usuario no encontrados"),
        @ApiResponse(responseCode = "500", description = "Error al obtener datos")
    })
    public ResponseEntity<?> DatosVentaUsuario(@PathVariable Long idventa) {
        try {
            venta ventabuscada = ventaservice.BuscarUnaVenta(idventa);
            UsuarioDTO usuarioVenta = ventaservice.BuscarUsuario(ventabuscada.getRutusuario());
            ventaUsuarioDTO ventausuario = new ventaUsuarioDTO();
            ventausuario.setFechaventa(ventabuscada.getFechaventa());
            ventausuario.setIdventa(ventabuscada.getIdventa());
            ventausuario.setRutusuario(ventabuscada.getRutusuario());
            ventausuario.setNombre(usuarioVenta.getNombre());
            ventausuario.setMail(usuarioVenta.getMail());
            return ResponseEntity.ok(ventausuario);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no se encuentran ventas o el usuario no esta registrado");
        }
    }

    @PostMapping
    @Operation(summary = "Registrar una nueva venta")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Venta registrada exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = venta.class))),
        @ApiResponse(responseCode = "409", description = "Conflicto al registrar la venta"),
        @ApiResponse(responseCode = "500", description = "Error al registrar venta")
    })
    public ResponseEntity<?> GuardarVenta(@RequestBody venta ventaguardar) {
        try {
            venta ventaregistrar = ventaservice.GuardarVenta(ventaguardar);
            return ResponseEntity.status(HttpStatus.CREATED).body(ventaregistrar);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("No se puede registrar la venta");
        }
    }

    @DeleteMapping("/{idventa}")
    @Operation(summary = "Eliminar una venta por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Venta eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Venta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar venta")
    })
    public ResponseEntity<String> EliminarVenta(@PathVariable Long idventa) {
        try {
            venta ventabuscada = ventaservice.BuscarUnaVenta(idventa);
            ventaservice.EliminarVenta(idventa);
            return ResponseEntity.status(HttpStatus.OK).body("Se elimino la venta");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Venta no esta registrada");
        }
    }

    @PutMapping("/{idventa}")
    @Operation(summary = "Actualizar los datos de una venta")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Venta actualizada correctamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = venta.class))),
        @ApiResponse(responseCode = "404", description = "Venta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar venta")
    })
    public ResponseEntity<?> ActualizarVenta(@PathVariable Long idventa, @RequestBody venta ventaactualizar) {
        try {
            venta ventaactualizada = ventaservice.BuscarUnaVenta(idventa);
            ventaactualizada.setRutusuario(ventaactualizar.getRutusuario());
            ventaactualizada.setFechaventa(ventaactualizar.getFechaventa());
            ventaactualizada.setTotalventa(ventaactualizar.getTotalventa());
            ventaservice.GuardarVenta(ventaactualizada);
            return ResponseEntity.ok(ventaactualizada);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Venta no esta registrada");
        }
    }
}
