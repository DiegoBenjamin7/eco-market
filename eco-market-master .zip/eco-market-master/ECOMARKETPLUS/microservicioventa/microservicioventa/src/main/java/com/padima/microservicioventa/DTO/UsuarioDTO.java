package com.padima.microservicioventa.DTO;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsuarioDTO {

   private String rut;

    private String nombre;

    private String mail;

    private long Telefono;

    private String direccion;
}
