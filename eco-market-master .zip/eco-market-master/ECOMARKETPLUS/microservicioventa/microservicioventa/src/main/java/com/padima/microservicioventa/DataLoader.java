package com.padima.microservicioventa;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.padima.microservicioventa.model.venta;
import com.padima.microservicioventa.service.ventaService;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private ventaService ventaService;

    @Override
    public void run(String... args) throws Exception {
        for (int i = 0; i < 15; i++) {
            venta nuevaVenta = new venta();
            
            nuevaVenta.setTotalventa(String.valueOf(10000 + (int)(Math.random() * 90000)));
        
            nuevaVenta.setRutusuario(generarRutEjemplo());
            
            nuevaVenta.setFechaventa(LocalDate.now().minusDays(i));
            
            ventaService.GuardarVenta(nuevaVenta);
            System.out.println("Venta creada - ID: " + nuevaVenta.getIdventa());
        }
    }
    private String generarRutEjemplo() {
        int numero = 15000000 + (int)(Math.random() * 20000000);
        return numero + "-" + calcularDigito(numero);
    }
    private char calcularDigito(int rut) {
        int m = 0, s = 1;
        for (; rut != 0; rut /= 10) {
            s = (s + rut % 10 * (9 - m++ % 6)) % 11;
        }
        return (char)(s != 0 ? s + 47 : 'K');
    }
}