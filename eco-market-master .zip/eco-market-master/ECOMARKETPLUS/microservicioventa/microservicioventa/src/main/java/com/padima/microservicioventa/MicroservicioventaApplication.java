package com.padima.microservicioventa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioventaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioventaApplication.class, args);
	}

}
