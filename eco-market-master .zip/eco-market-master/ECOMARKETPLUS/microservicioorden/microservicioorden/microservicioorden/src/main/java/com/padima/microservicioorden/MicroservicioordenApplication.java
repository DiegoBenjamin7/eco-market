package com.padima.microservicioorden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioordenApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioordenApplication.class, args);
	}

}
