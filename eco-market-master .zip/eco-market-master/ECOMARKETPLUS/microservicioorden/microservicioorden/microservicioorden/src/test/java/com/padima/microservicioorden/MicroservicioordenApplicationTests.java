package com.padima.microservicioorden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioordenApplicationTests {

	@Test
	void contextLoads() {
	}

}
