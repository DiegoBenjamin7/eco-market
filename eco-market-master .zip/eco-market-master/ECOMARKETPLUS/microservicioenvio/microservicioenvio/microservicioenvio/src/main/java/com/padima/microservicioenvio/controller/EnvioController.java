package com.padima.microservicioenvio.controller;

import com.padima.microservicioenvio.model.Envio;
import com.padima.microservicioenvio.service.EnvioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/envios")
@Tag(name = "Envio", description = "Operaciones relacionadas con el envío de productos")
public class EnvioController {

    @Autowired
    private EnvioService envioService;

    @PostMapping
    @Operation(summary = "Crear nuevo Envío")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Envío creado exitosamente", 
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Envio.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear el envío"),
        @ApiResponse(responseCode = "500", description = "Error interno al crear envío")
    })
    public ResponseEntity<Envio> crearEnvio(@RequestBody Envio envio) {
        try {
            Envio nuevoEnvio = envioService.crearEnvio(envio);
            return new ResponseEntity<>(nuevoEnvio, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener Envío por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Envío encontrado"),
        @ApiResponse(responseCode = "404", description = "Envío no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al buscar envío")
    })
    public ResponseEntity<Envio> obtenerEnvio(@PathVariable Long id) {
        Optional<Envio> envio = envioService.buscarEnvioPorId(id);
        return envio.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    @Operation(summary = "Listar todos los envíos")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de envíos obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error al obtener la lista de envíos")
    })
    public ResponseEntity<List<Envio>> listarEnvios() {
        return ResponseEntity.ok(envioService.listarTodosLosEnvios());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un envío existente")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Envío actualizado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para actualizar envío"),
        @ApiResponse(responseCode = "404", description = "Envío no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar envío")
    })
    public ResponseEntity<Envio> actualizarEnvio(
            @PathVariable Long id,
            @RequestBody Envio envioActualizado) {
        try {
            return ResponseEntity.ok(envioService.actualizarEnvio(id, envioActualizado));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un envío por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Envío eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Envío no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar envío")
    })
    public ResponseEntity<Void> eliminarEnvio(@PathVariable Long id) {
        try {
            envioService.eliminarEnvio(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/estado/{estado}")
    @Operation(summary = "Obtener envíos por estado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de envíos obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error al filtrar envíos por estado")
    })
    public ResponseEntity<List<Envio>> obtenerPorEstado(@PathVariable String estado) {
        return ResponseEntity.ok(envioService.obtenerEnviosPorEstado(estado));
    }

    @PostMapping("/{id}/cambiar-estado")
    @Operation(summary = "Cambiar estado del envío")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Estado del envío actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Estado inválido o mal formato"),
        @ApiResponse(responseCode = "404", description = "Envío no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al cambiar el estado del envío")
    })
    public ResponseEntity<Envio> cambiarEstado(
            @PathVariable Long id,
            @RequestBody String nuevoEstado) {
        try {
            return ResponseEntity.ok(envioService.cambiarEstadoEnvio(id, nuevoEstado));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/buscar")
    @Operation(summary = "Buscar envíos por código, ruta o estado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda realizada con éxito"),
        @ApiResponse(responseCode = "400", description = "Parámetros de búsqueda inválidos"),
        @ApiResponse(responseCode = "500", description = "Error al buscar los envíos")
    })
    public ResponseEntity<List<Envio>> buscarEnvios(
            @RequestParam(required = false) String codigo,
            @RequestParam(required = false) Long idRuta,
            @RequestParam(required = false) String estado) {
        return ResponseEntity.ok(envioService.buscarEnvios(codigo, idRuta, estado));
    }
}