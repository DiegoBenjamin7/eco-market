package com.padima.microservicioenvio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioenvioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioenvioApplication.class, args);
	}

}
