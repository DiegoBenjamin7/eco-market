package com.padima.microservicioruta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciorutaApplicationTests {

	@Test
	void contextLoads() {
	}

}
