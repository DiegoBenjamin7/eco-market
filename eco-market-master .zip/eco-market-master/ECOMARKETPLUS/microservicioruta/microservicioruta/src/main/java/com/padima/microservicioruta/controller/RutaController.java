package com.padima.microservicioruta.controller;

import com.padima.microservicioruta.assembler.RutaModelAssembler;
import com.padima.microservicioruta.model.Ruta;
import com.padima.microservicioruta.service.RutaService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

@RestController
@RequestMapping("/api/rutas")
public class RutaController {

    private final RutaService rutaService;
    private final RutaModelAssembler assembler;

    public RutaController(RutaService rutaService, RutaModelAssembler assembler) {
        this.rutaService = rutaService;
        this.assembler = assembler;
    }

    @Operation(summary = "Crear una nueva ruta", description = "Registra una nueva ruta en el sistema.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Ruta creada exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Ruta.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear la ruta"),
        @ApiResponse(responseCode = "500", description = "Error al crear la ruta")
    })
    @PostMapping
    public ResponseEntity<EntityModel<Ruta>> crearRuta(@RequestBody Ruta nuevaRuta) {
        Ruta rutaCreada = rutaService.crearRuta(nuevaRuta);
        EntityModel<Ruta> entityModel = assembler.toModel(rutaCreada);
        return ResponseEntity
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri())
                .body(entityModel);
    }

    @Operation(summary = "Obtener una ruta por ID", description = "Devuelve una ruta específica por su identificador.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Ruta encontrada",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Ruta.class))),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al buscar la ruta")
    })
    @GetMapping("/{id}")
    public EntityModel<Ruta> buscarRutaPorId(@PathVariable Long id) {
        Ruta ruta = rutaService.buscarRutaPorId(id);
        return assembler.toModel(ruta);
    }

    @Operation(summary = "Buscar rutas con filtros opcionales", description = "Devuelve una lista de rutas filtradas por origen, destino o tipo de transporte.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Rutas encontradas"),
        @ApiResponse(responseCode = "500", description = "Error al buscar rutas")
    })
    @GetMapping
    public CollectionModel<EntityModel<Ruta>> buscarRutas(
            @RequestParam(required = false) String origen,
            @RequestParam(required = false) String destino,
            @RequestParam(required = false) String tipoTransporte) {
        List<EntityModel<Ruta>> rutas = rutaService.buscarRutasDisponibles(origen, destino, tipoTransporte)
                .stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(rutas,
                linkTo(methodOn(RutaController.class).buscarRutas(origen, destino, tipoTransporte)).withSelfRel());
    }

    @Operation(summary = "Obtener rutas activas", description = "Devuelve una lista de rutas activas.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Rutas activas encontradas"),
        @ApiResponse(responseCode = "500", description = "Error al obtener rutas activas")
    })
    @GetMapping("/activas")
    public CollectionModel<EntityModel<Ruta>> obtenerRutasActivas() {
        List<EntityModel<Ruta>> rutas = rutaService.obtenerRutasActivas()
                .stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(rutas,
                linkTo(methodOn(RutaController.class).obtenerRutasActivas()).withSelfRel());
    }

    @Operation(summary = "Actualizar ruta completa", description = "Actualiza completamente los datos de una ruta existente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Ruta actualizada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada para actualizar"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar la ruta")
    })
    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<Ruta>> actualizarRuta(
            @PathVariable Long id,
            @RequestBody Ruta rutaActualizada) {
        Ruta ruta = rutaService.actualizarRuta(id, rutaActualizada);
        EntityModel<Ruta> entityModel = assembler.toModel(ruta);
        return ResponseEntity.ok(entityModel);
    }

    @Operation(summary = "Cambiar estado de la ruta", description = "Modifica el estado actual de una ruta.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Estado de la ruta actualizado correctamente"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al cambiar el estado de la ruta")
    })
    @PutMapping("/{id}/estado")
    public ResponseEntity<EntityModel<Ruta>> cambiarEstado(
            @PathVariable Long id,
            @RequestParam String estado) {
        Ruta ruta = rutaService.cambiarEstadoRuta(id, estado);
        EntityModel<Ruta> entityModel = assembler.toModel(ruta);
        return ResponseEntity.ok(entityModel);
    }

    @Operation(summary = "Eliminar una ruta", description = "Elimina del sistema una ruta especificada por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Ruta eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar la ruta")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarRuta(@PathVariable Long id) {
        rutaService.eliminarRuta(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Buscar rutas por tipo de transporte", description = "Filtra y retorna rutas según el tipo de transporte.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Rutas encontradas por tipo de transporte"),
        @ApiResponse(responseCode = "500", description = "Error al filtrar rutas")
    })
    @GetMapping("/por-transporte/{tipoTransporte}")
    public CollectionModel<EntityModel<Ruta>> buscarPorTipoTransporte(
            @PathVariable String tipoTransporte) {
        List<EntityModel<Ruta>> rutas = rutaService.buscarPorTipoTransporte(tipoTransporte)
                .stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(rutas,
                linkTo(methodOn(RutaController.class).buscarPorTipoTransporte(tipoTransporte)).withSelfRel());
    }
}
