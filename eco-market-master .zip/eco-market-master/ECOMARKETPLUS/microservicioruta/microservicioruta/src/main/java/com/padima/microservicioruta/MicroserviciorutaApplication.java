package com.padima.microservicioruta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviciorutaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviciorutaApplication.class, args);
	}

}
