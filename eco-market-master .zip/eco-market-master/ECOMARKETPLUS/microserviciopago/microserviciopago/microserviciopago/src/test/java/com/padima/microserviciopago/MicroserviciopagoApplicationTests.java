package com.padima.microserviciopago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciopagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
