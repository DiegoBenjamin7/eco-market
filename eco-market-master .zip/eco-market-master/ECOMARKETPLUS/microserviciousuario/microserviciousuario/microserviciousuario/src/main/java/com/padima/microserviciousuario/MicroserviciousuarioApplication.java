package com.padima.microserviciousuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviciousuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviciousuarioApplication.class, args);
	}

}
