package com.padima.microserviciousuario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.padima.microserviciousuario.model.Usuario;
import com.padima.microserviciousuario.services.UsuarioService;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;




import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

@RestController
@RequestMapping("/api/v1/Usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioservice;

    @Operation(summary = "Listar todos los usuarios", description = "Retorna una lista con todos los usuarios del sistema")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de usuarios obtenida correctamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Usuario.class))),
        @ApiResponse(responseCode = "204", description = "No hay usuarios disponibles"),
        @ApiResponse(responseCode = "500", description = "Error del servidor")
    })
    @GetMapping
    public ResponseEntity<List<Usuario>> ListarUsuario(){
        List<Usuario> usuarios = usuarioservice.BuscarTodo();
        if(usuarios.isEmpty()){
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(usuarios);
        }
    }

    @Operation(summary = "Buscar un usuario por RUT", description = "Busca y devuelve un usuario según el RUT proporcionado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Usuario encontrado",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Usuario.class))),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error del servidor")
    })
    @GetMapping("/{rut}")
    public ResponseEntity<?> BuscarUsuario(@PathVariable String rut){
        try {
            Usuario usuario = usuarioservice.BuscarUsuario(rut);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentra el usuario");
        }
    }

    @Operation(summary = "Registrar un nuevo usuario", description = "Crea un nuevo usuario a partir de los datos enviados en la solicitud")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Usuario creado exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Usuario.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear el usuario"),
        @ApiResponse(responseCode = "500", description = "Error al crear el usuario")
    })
    @PostMapping
    public ResponseEntity<String> guardarUsuario(@RequestBody Usuario usuario){
        try {
            Usuario usuarioCrear = usuarioservice.BuscarUsuario(usuario.getRut());
            return ResponseEntity.status(HttpStatus.CONFLICT).body("El rut esta registrado");
        } catch (Exception e) {
            Usuario usuarioNuevo = usuarioservice.GuardarUsuario(usuario);
            return ResponseEntity.status(HttpStatus.CREATED).body("Usuario registrado de manera exitosa");
        } 
    }

    @Operation(summary = "Eliminar usuario", description = "Elimina un usuario según su RUT")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Usuario eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado para eliminar"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar el usuario")
    })
    @DeleteMapping("/{rut}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable String rut){
        try {
            Usuario usuarioEliminar = usuarioservice.BuscarUsuario(rut);
            usuarioservice.EliminarUsuario(rut);
            return ResponseEntity.status(HttpStatus.OK).body("Usuario eliminado de manera exitosa");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario que desea eliminar no existe");
        }
    }

    @Operation(summary = "Actualizar usuario", description = "Actualiza los datos de un usuario ya registrado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Usuario actualizado correctamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado para actualizar"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar el usuario")
    })
    @PutMapping("/{rut}")
    public ResponseEntity<?> actualizar(@PathVariable String rut, @RequestBody Usuario usuarioActualizar){
        try {
            Usuario BuscarUsuario = usuarioservice.BuscarUsuario(rut);
            BuscarUsuario.setRut(rut);
            BuscarUsuario.setNombre(usuarioActualizar.getNombre());
            BuscarUsuario.setMail(usuarioActualizar.getMail());
            BuscarUsuario.setTelefono(usuarioActualizar.getTelefono());
            BuscarUsuario.setDireccion(usuarioActualizar.getDireccion());

            usuarioservice.GuardarUsuario(BuscarUsuario);
            return ResponseEntity.ok(usuarioActualizar);

        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("EL ID DEL USUARIO NO ESTÁ REGISTRADO EN LA BASE DE DATOS PARA PODER SER ACTUALIZADO");
        }
    }
}
