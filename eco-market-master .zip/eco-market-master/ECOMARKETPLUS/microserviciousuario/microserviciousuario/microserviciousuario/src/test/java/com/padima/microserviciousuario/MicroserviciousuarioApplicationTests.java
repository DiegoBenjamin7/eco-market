package com.padima.microserviciousuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciousuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
