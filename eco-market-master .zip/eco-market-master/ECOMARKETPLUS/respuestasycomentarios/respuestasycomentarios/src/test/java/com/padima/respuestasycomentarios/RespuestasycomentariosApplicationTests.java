package com.padima.respuestasycomentarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RespuestasycomentariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
