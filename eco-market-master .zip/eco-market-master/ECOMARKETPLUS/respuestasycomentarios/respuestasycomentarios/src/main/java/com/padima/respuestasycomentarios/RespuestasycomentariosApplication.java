package com.padima.respuestasycomentarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RespuestasycomentariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(RespuestasycomentariosApplication.class, args);
	}

}
