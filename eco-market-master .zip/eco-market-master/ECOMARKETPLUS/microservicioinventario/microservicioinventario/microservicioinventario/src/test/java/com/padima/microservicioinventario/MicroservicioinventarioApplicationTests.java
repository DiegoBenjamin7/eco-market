package com.padima.microservicioinventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioinventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
