package com.padima.microservicioinventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioinventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioinventarioApplication.class, args);
	}

}
