package com.padima.microservicioreporte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioreporteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioreporteApplication.class, args);
	}

}
