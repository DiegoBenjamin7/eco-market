package com.padima.microserviciocrearcuenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviciocrearcuentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviciocrearcuentaApplication.class, args);
	}

}
