package com.padima.microserviciocrearcuenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciocrearcuentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
