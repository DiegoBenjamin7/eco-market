package com.padima.microserviciofactura.model;
// src/main/java/com/example/invoiceservice/model/Invoice.java


import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

import com.padima.microserviciofactura.model.Factura.FacturaStatus;

@Data
@Entity
@Table(name = "Facturas")
public class Factura {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String vendedorId;
    
    @ElementCollection
    private List<String> productoId;
    
    @Column(nullable = false)
    private Double totalMonto;
    
    @Column(nullable = false)
    private LocalDateTime fechaFactura;
    
    @Enumerated(EnumType.STRING)
    private FacturaStatus estado;

    public enum FacturaStatus {
    PENDIENTE,
    PAGO,
    CANCELADO
    }
}
