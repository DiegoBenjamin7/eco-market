package com.padima.microserviciofactura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviciofacturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviciofacturaApplication.class, args);
	}

}
