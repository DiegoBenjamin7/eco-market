package com.padima.microserviciofactura.dto;


import com.padima.microserviciofactura.model.Factura.FacturaStatus;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class FacturaDTO {
    private Long id;
    private String vendedorId;
    private List<String> productoId;
    private Double totalMonto;
    private LocalDateTime fechaFactura;
    private FacturaStatus estado;
}
