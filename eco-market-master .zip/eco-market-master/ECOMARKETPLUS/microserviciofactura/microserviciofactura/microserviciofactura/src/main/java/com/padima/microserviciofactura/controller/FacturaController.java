package com.padima.microserviciofactura.controller;

import com.padima.microserviciofactura.dto.FacturaDTO;
import com.padima.microserviciofactura.service.FacturaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ecomarket/facturas")
@Tag(name = "Factura Controller", description = "API para gestión de facturas")
public class FacturaController {

    private final FacturaService facturaService;

    @Autowired
    public FacturaController(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    @PostMapping
    @Operation(summary = "Crear una nueva factura")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Factura creada exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = FacturaDTO.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear factura"),
        @ApiResponse(responseCode = "500", description = "Error interno al crear factura")
    })
    public ResponseEntity<FacturaDTO> createFactura(@RequestBody FacturaDTO facturaDTO) {
        FacturaDTO nuevaFactura = facturaService.createFactura(facturaDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaFactura);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener factura por la ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Factura encontrada"),
        @ApiResponse(responseCode = "404", description = "Factura no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al obtener la factura")
    })
    public ResponseEntity<FacturaDTO> getFacturaById(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.getFacturaById(id));
    }

    @GetMapping
    @Operation(summary = "Obtener todas las facturas")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Facturas obtenidas exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error al obtener facturas")
    })
    public ResponseEntity<List<FacturaDTO>> getAllFacturas() {
        return ResponseEntity.ok(facturaService.getAllFacturas());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar factura que ya existe")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Factura actualizada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para actualizar factura"),
        @ApiResponse(responseCode = "404", description = "Factura no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar factura")
    })
    public ResponseEntity<FacturaDTO> updateFactura(
            @PathVariable Long id,
            @RequestBody FacturaDTO facturaDTO) {
        return ResponseEntity.ok(facturaService.updateFactura(id, facturaDTO));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una factura")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Factura eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Factura no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar factura")
    })
    public ResponseEntity<Void> deleteFactura(@PathVariable Long id) {
        facturaService.deleteFactura(id);
        return ResponseEntity.noContent().build();
    }
}