package com.padima.microserviciofactura.assembler;
// src/main/java/com/padima/microserviciofactura/assembler/FacturaAssembler.java

import com.padima.microserviciofactura.dto.FacturaDTO;
import com.padima.microserviciofactura.model.Factura;
import com.padima.microserviciofactura.dto.FacturaDTO;
import com.padima.microserviciofactura.model.Factura;

import org.springframework.stereotype.Component;
@Component
public class FacturaAssembler {
    public FacturaDTO toDto(Factura factura) {
        FacturaDTO dto = new FacturaDTO();
        dto.setId(factura.getId());
        dto.setVendedorId(factura.getVendedorId());
        dto.setProductoId(factura.getProductoId());
        dto.setTotalMonto(factura.getTotalMonto());
        dto.setFechaFactura(factura.getFechaFactura());
        dto.setEstado(factura.getEstado());
        return dto;
    }
    public Factura toEntity(FacturaDTO dto) {
        Factura factura = new Factura();
        factura.setVendedorId(dto.getVendedorId());
        factura.setProductoId(dto.getProductoId());
        factura.setTotalMonto(dto.getTotalMonto());
        factura.setFechaFactura(dto.getFechaFactura());
        factura.setEstado(dto.getEstado());
        return factura;
    }
}