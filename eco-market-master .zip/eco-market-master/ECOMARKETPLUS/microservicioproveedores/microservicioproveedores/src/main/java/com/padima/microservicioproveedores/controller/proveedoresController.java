package com.padima.microservicioproveedores.controller;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.padima.microservicioproveedores.assembler.proveedoresAssembler;
import com.padima.microservicioproveedores.model.proveedores;
import com.padima.microservicioproveedores.service.proveedoresService;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/proveedores")
@Tag(name = "Proveedores", description = "API para la gestión de proveedores")
public class proveedoresController {

    private final proveedoresService proveedoresService;
    private final proveedoresAssembler assembler;

    public proveedoresController(proveedoresService proveedoresService, proveedoresAssembler assembler) {
        this.proveedoresService = proveedoresService;
        this.assembler = assembler;
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo proveedor")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Proveedor creado exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = proveedores.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear proveedor"),
        @ApiResponse(responseCode = "500", description = "Error al crear proveedor")
    })
    public ResponseEntity<EntityModel<proveedores>> crearProveedor(@RequestBody proveedores nuevoProveedor) {
        proveedores proveedorCreado = proveedoresService.crearProveedor(nuevoProveedor);
        EntityModel<proveedores> entityModel = assembler.toModel(proveedorCreado);
        return ResponseEntity
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri())
                .body(entityModel);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar proveedor por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedor encontrado"),
        @ApiResponse(responseCode = "404", description = "Proveedor no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al buscar proveedor")
    })
    public EntityModel<proveedores> buscarProveedorPorId(@PathVariable Long id) {
        proveedores proveedor = proveedoresService.buscarProveedorPorId(id);
        return assembler.toModel(proveedor);
    }

    @GetMapping
    @Operation(summary = "Listar proveedores con filtros opcionales por tipo y nombre")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedores listados correctamente"),
        @ApiResponse(responseCode = "500", description = "Error al listar proveedores")
    })
    public CollectionModel<EntityModel<proveedores>> listarProveedores(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) String nombre) {
        
        List<proveedores> proveedoresFiltrados;
        
        if (tipo != null && nombre != null) {
            proveedoresFiltrados = proveedoresService.buscarPorTipoYNombre(tipo, nombre);
        } else if (tipo != null) {
            proveedoresFiltrados = proveedoresService.buscarProveedoresPorTipo(tipo);
        } else if (nombre != null) {
            proveedoresFiltrados = proveedoresService.buscarPorNombreContaining(nombre);
        } else {
            proveedoresFiltrados = proveedoresService.obtenerTodosProveedores();
        }
        
        List<EntityModel<proveedores>> proveedores = proveedoresFiltrados.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        
        return CollectionModel.of(proveedores,
                linkTo(methodOn(proveedoresController.class).listarProveedores(tipo, nombre)).withSelfRel());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar proveedor existente")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedor actualizado correctamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = proveedores.class))),
        @ApiResponse(responseCode = "404", description = "Proveedor no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al actualizar proveedor")
    })
    public ResponseEntity<EntityModel<proveedores>> actualizarProveedor(
            @PathVariable Long id,
            @RequestBody proveedores proveedorActualizado) {
        proveedores proveedor = proveedoresService.actualizarProveedor(id, proveedorActualizado);
        EntityModel<proveedores> entityModel = assembler.toModel(proveedor);
        return ResponseEntity.ok(entityModel);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar proveedor por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Proveedor eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Proveedor no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error al eliminar proveedor")
    })
    public ResponseEntity<?> eliminarProveedor(@PathVariable Long id) {
        proveedoresService.eliminarProveedor(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/porTipo/{tipo}")
    @Operation(summary = "Buscar proveedores por tipo")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedores encontrados"),
        @ApiResponse(responseCode = "500", description = "Error al buscar proveedores por tipo")
    })
    public CollectionModel<EntityModel<proveedores>> buscarPorTipo(@PathVariable String tipo) {
        List<EntityModel<proveedores>> proveedores = proveedoresService.buscarProveedoresPorTipo(tipo).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(proveedores,
                linkTo(methodOn(proveedoresController.class).buscarPorTipo(tipo)).withSelfRel());
    }
}
