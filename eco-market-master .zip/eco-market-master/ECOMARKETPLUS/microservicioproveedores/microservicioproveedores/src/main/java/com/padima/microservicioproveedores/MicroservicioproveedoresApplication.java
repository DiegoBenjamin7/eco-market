package com.padima.microservicioproveedores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioproveedoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioproveedoresApplication.class, args);
	}

}
