package com.padima.microservicioproveedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioproveedoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
